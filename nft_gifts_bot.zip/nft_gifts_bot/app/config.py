import os
from dataclasses import dataclass
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Config:
    bot_token: str
    see_tg_token: str
    database_path: str
    radar_poll_fallback_seconds: int

def load_config() -> Config:
    bot_token = os.getenv("BOT_TOKEN", "").strip()
    if not bot_token or bot_token == "put_telegram_bot_token_here":
        raise RuntimeError("Укажите BOT_TOKEN в файле .env (токен от @BotFather).")
    db_path = os.getenv("DATABASE_PATH", "data/bot.sqlite3")
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    return Config(
        bot_token=bot_token,
        see_tg_token=os.getenv("SEE_TG_TOKEN", "").strip(),
        database_path=db_path,
        radar_poll_fallback_seconds=int(os.getenv("RADAR_POLL_FALLBACK_SECONDS", "60")),
    )
