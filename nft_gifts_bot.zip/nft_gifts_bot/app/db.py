import sqlite3
from pathlib import Path
from typing import Any

class Database:
    def __init__(self, path: str):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self._init()

    def _connect(self):
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        return con

    def _init(self):
        with self._connect() as con:
            con.executescript('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                radar_enabled INTEGER NOT NULL DEFAULT 0,
                max_price_ton REAL,
                collection TEXT,
                model TEXT,
                backdrop TEXT,
                pattern TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS seen_events (
                event_id TEXT PRIMARY KEY,
                seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            ''')

    def ensure_user(self, user_id: int):
        with self._connect() as con:
            con.execute("INSERT OR IGNORE INTO users(user_id) VALUES(?)", (user_id,))

    def get_user(self, user_id: int) -> dict[str, Any]:
        self.ensure_user(user_id)
        with self._connect() as con:
            row = con.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
            return dict(row)

    def update_radar(self, user_id: int, **values):
        allowed = {"radar_enabled", "max_price_ton", "collection", "model", "backdrop", "pattern"}
        values = {k: v for k, v in values.items() if k in allowed}
        if not values:
            return
        self.ensure_user(user_id)
        clause = ", ".join(f"{key}=?" for key in values)
        with self._connect() as con:
            con.execute(f"UPDATE users SET {clause} WHERE user_id=?", (*values.values(), user_id))

    def enabled_users(self) -> list[dict[str, Any]]:
        with self._connect() as con:
            return [dict(row) for row in con.execute("SELECT * FROM users WHERE radar_enabled=1")]

    def mark_event_seen(self, event_id: str) -> bool:
        if not event_id:
            return False
        with self._connect() as con:
            try:
                con.execute("INSERT INTO seen_events(event_id) VALUES(?)", (event_id,))
                return True
            except sqlite3.IntegrityError:
                return False
