import asyncio
import logging
import re
from urllib.parse import urlparse
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder
from .config import load_config
from .db import Database
from .providers.see_tg import SeeTGProvider, ProviderError, normalize_history, unwrap_events
from .valuation import value_history, format_ton
from .radar import run_radar

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
cfg = load_config()
db = Database(cfg.database_path)
provider = SeeTGProvider(cfg.see_tg_token)
dp = Dispatcher()

def main_keyboard():
    kb = InlineKeyboardBuilder()
    kb.button(text="📊 Оценить подарок", callback_data="value")
    kb.button(text="🎯 Gift Radar", callback_data="radar")
    kb.button(text="⚙️ Настроить радар", callback_data="radar_setup")
    kb.adjust(1)
    return kb.as_markup()

def radar_keyboard():
    kb = InlineKeyboardBuilder()
    kb.button(text="🛠 Настроить фильтры", callback_data="radar_setup")
    kb.button(text="▶️ Включить радар", callback_data="radar_on")
    kb.button(text="⏸ Выключить радар", callback_data="radar_off")
    kb.button(text="⬅️ Главное меню", callback_data="home")
    kb.adjust(1)
    return kb.as_markup()

def parse_ref(text: str) -> str | None:
    text = text.strip()
    # Accept raw slug-N / numeric ID, or known Telegram NFT/see.tg URLs.
    if re.fullmatch(r"[A-Za-z0-9_-]{1,100}", text):
        return text
    parsed = urlparse(text)
    host = (parsed.netloc or "").lower().removeprefix("www.")
    if host not in {"t.me", "telegram.me", "see.tg", "www.see.tg"}:
        return None
    path = parsed.path.strip("/")
    if path.startswith("nft/"):
        path = path[4:]
    if path.startswith("gift/"):
        path = path[5:]
    if re.fullmatch(r"[A-Za-z0-9_-]{1,100}", path):
        return path
    return None

@dp.message(CommandStart())
async def start(message: Message):
    db.ensure_user(message.from_user.id)
    await message.answer(
        "👋 <b>NFT Gifts Radar</b>\n\n"
        "Оценивай Telegram NFT-подарки по истории событий и находи новые лоты через радар.\n\n"
        "• История для оценки фильтруется с 1 января 2026 года.\n"
        "• Листинг — цена продавца; продажа — цена сделки.\n"
        "• Если данных недостаточно, бот не придумывает оценку.\n\n"
        "Выбери действие:", reply_markup=main_keyboard()
    )

@dp.message(Command("help"))
async def help_cmd(message: Message):
    await message.answer(
        "Как пользоваться:\n"
        "1) Нажми «Оценить подарок» и отправь ссылку или slug, например PlushPepe-123.\n"
        "2) В настройках радара задай бюджет и необязательные атрибуты.\n"
        "3) Включи радар — уведомления приходят при новых подходящих событиях.\n\n"
        "Для работы нужен SEE_TG_TOKEN в .env."
    )

@dp.callback_query(F.data == "home")
async def home(call: CallbackQuery):
    await call.message.edit_text("Главное меню NFT Gifts Radar:", reply_markup=main_keyboard())
    await call.answer()

@dp.callback_query(F.data == "value")
async def value_start(call: CallbackQuery):
    await call.message.answer("Отправь ссылку на подарок, например https://t.me/nft/PlushPepe-123, или его slug/номер.")
    await call.answer()

@dp.message(F.text)
async def handle_text(message: Message):
    text = (message.text or "").strip()
    if text.startswith("/"):
        return
    # Leave radar-filter lines for the dedicated handler below.
    if re.match(r"^\s*\d+(?:[.,]\d+)?;", text):
        return
    ref = parse_ref(text)
    if not ref:
        await message.answer("Не смог распознать ссылку. Пришли ссылку вида https://t.me/nft/Collection-123 или slug/ID подарка.")
        return
    if not cfg.see_tg_token:
        await message.answer("⚠️ Не задан SEE_TG_TOKEN. Добавь токен see.tg API в файл .env и перезапусти бота.")
        return
    await message.answer("🔎 Получаю историю подарка из see.tg…")
    try:
        payload = await provider.gift_history(ref)
    except ProviderError as exc:
        await message.answer(f"Не удалось получить историю: {exc}")
        return
    except Exception:
        logging.exception("History lookup failed")
        await message.answer("Не удалось связаться с API. Проверь токен и попробуй позже.")
        return
    rows = normalize_history(payload)
    result = value_history(rows)
    events = unwrap_events(payload)
    sales_2026 = []
    listings = []
    for row in rows:
        at = row["at"]
        if not at or at.year < 2026:
            continue
        if any(k in row["kind"] for k in ("sale", "sold", "purchase")):
            sales_2026.append(row)
        elif "listing" in row["kind"] or "price" in row["kind"]:
            listings.append(row)
    if not events:
        await message.answer("API вернул историю в неизвестном формате или без событий. Оценку не рассчитал, чтобы не выдумывать цену.")
        return
    latest_listing = next((r for r in listings if r["price_ton"] is not None), None)
    lines = [f"📊 <b>Анализ подарка</b>\nID/slug: <code>{ref}</code>",
             f"Продаж с ценой, найденных с 01.01.2026: <b>{result['count']}</b>"]
    if result["count"]:
        lines += [
            f"Медиана продаж: <b>{format_ton(result['median'])}</b>",
            f"Средняя цена продаж: {format_ton(result['average'])}",
            f"Последняя найденная продажа: {format_ton(result['latest'])}",
            f"Дата последней продажи: {result['latest_date'].strftime('%Y-%m-%d %H:%M UTC')}",
        ]
    else:
        lines.append("Недостаточно доступных продаж с известной ценой за период с 2026 года — надёжную оценку рассчитать нельзя.")
    if latest_listing:
        lines.append(f"Последняя найденная цена листинга: {format_ton(latest_listing['price_ton'])} (это цена продавца, не продажа).")
    lines.append(f"Событий получено от источника: {len(rows)}.")
    lines.append("Источник: see.tg Public API. Это ориентир, не финансовая рекомендация.")
    await message.answer("\n".join(lines), reply_markup=main_keyboard())

@dp.callback_query(F.data == "radar")
async def radar(call: CallbackQuery):
    user = db.get_user(call.from_user.id)
    status = "включён" if user["radar_enabled"] else "выключен"
    lines = [
        f"🎯 <b>Gift Radar</b> — {status}",
        f"Максимальная цена: {user['max_price_ton'] if user['max_price_ton'] is not None else 'не задана'} TON",
        f"Коллекция: {user['collection'] or 'любая'}",
        f"Модель: {user['model'] or 'любая'}",
        f"Фон: {user['backdrop'] or 'любой'}",
        f"Узор: {user['pattern'] or 'любой'}",
        "\nРадар отправляет уведомления о новых подходящих листингах из live-потока see.tg."
    ]
    await call.message.answer("\n".join(lines), reply_markup=radar_keyboard())
    await call.answer()

@dp.callback_query(F.data == "radar_setup")
async def radar_setup(call: CallbackQuery):
    await call.message.answer(
        "Пришли настройки одной строкой в формате:\n"
        "<code>цена;коллекция;модель;фон;узор</code>\n\n"
        "Пример: <code>50;PlushPepe;Cyberpunk;Onyx Black;Skull</code>\n"
        "Можно оставлять поля пустыми: <code>50;;;;</code>\n"
        "Цена обязательна, TON. Это простая MVP-настройка; значения атрибутов должны совпадать с данными источника."
    )
    await call.answer()

@dp.message(F.text.regexp(r"^\s*\d+(?:[.,]\d+)?;"))
async def save_radar_settings(message: Message):
    parts = [p.strip() for p in message.text.split(";")]
    if len(parts) != 5:
        await message.answer("Нужно ровно 5 полей: цена;коллекция;модель;фон;узор")
        return
    try:
        max_price = float(parts[0].replace(",", "."))
        if max_price <= 0:
            raise ValueError
    except ValueError:
        await message.answer("Цена должна быть положительным числом в TON.")
        return
    db.update_radar(
        message.from_user.id,
        max_price_ton=max_price,
        collection=parts[1] or None,
        model=parts[2] or None,
        backdrop=parts[3] or None,
        pattern=parts[4] or None,
    )
    await message.answer("✅ Фильтры сохранены. Теперь включи радар в меню Gift Radar.", reply_markup=main_keyboard())

@dp.callback_query(F.data == "radar_on")
async def radar_on(call: CallbackQuery):
    if not cfg.see_tg_token:
        await call.answer("Сначала добавь SEE_TG_TOKEN в .env", show_alert=True)
        return
    db.update_radar(call.from_user.id, radar_enabled=1)
    await call.message.answer("▶️ Радар включён. Убедись, что бот запущен на сервере.")
    await call.answer()

@dp.callback_query(F.data == "radar_off")
async def radar_off(call: CallbackQuery):
    db.update_radar(call.from_user.id, radar_enabled=0)
    await call.message.answer("⏸ Радар выключен.")
    await call.answer()

async def main():
    bot = Bot(cfg.bot_token)
    radar_task = asyncio.create_task(run_radar(bot, db, cfg.see_tg_token))
    try:
        await dp.start_polling(bot)
    finally:
        radar_task.cancel()
        await asyncio.gather(radar_task, return_exceptions=True)
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
