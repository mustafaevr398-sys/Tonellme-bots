import aiohttp
from datetime import datetime, timezone

BASE_URL = "https://kartoshka.free/v1"
START_2026 = datetime(2026, 1, 1, tzinfo=timezone.utc)

class ProviderError(RuntimeError):
    pass

class SeeTGProvider:
    def __init__(self, token: str):
        self.token = token

    def _headers(self):
        headers = {"Accept": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    async def _get(self, path: str, params: dict | None = None):
        timeout = aiohttp.ClientTimeout(total=20)
        async with aiohttp.ClientSession(timeout=timeout, headers=self._headers()) as session:
            async with session.get(f"{BASE_URL}{path}", params=params) as resp:
                body = await resp.json(content_type=None)
                if resp.status >= 400:
                    message = body.get("description", body.get("message", f"HTTP {resp.status}")) if isinstance(body, dict) else f"HTTP {resp.status}"
                    raise ProviderError(f"see.tg API: {message}")
                if isinstance(body, dict) and body.get("ok") is False:
                    raise ProviderError(body.get("description", "Неизвестная ошибка see.tg API"))
                return body.get("result", body) if isinstance(body, dict) else body

    async def gift_history(self, ref: str, limit: int = 100):
        # Documented endpoint: GET /v1/gift/{ref}/history
        return await self._get(f"/gift/{ref}/history", {"limit": min(max(limit, 1), 100), "order": "desc"})

def parse_date(value):
    if not value:
        return None
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, tz=timezone.utc)
    try:
        value = str(value).replace("Z", "+00:00")
        parsed = datetime.fromisoformat(value)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    except (ValueError, TypeError):
        return None

def unwrap_events(payload):
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ("items", "events", "history", "data"):
            if isinstance(payload.get(key), list):
                return payload[key]
    return []

def event_price_ton(event):
    # See.tg events may report amount in smallest currency units or explicit price_ton.
    price = event.get("price")
    if isinstance(price, dict):
        currency = str(price.get("currency", "")).lower()
        amount = price.get("amount")
        if currency in {"ton", "gram", "nano", "nanoton", "nanotons"} and isinstance(amount, (int, float)):
            return float(amount) / 1_000_000_000
    for key in ("price_ton", "amountTon", "amount_ton"):
        value = event.get(key)
        if isinstance(value, (int, float)):
            # price_ton is TON in the documented live example; amountTon in history may be nanotons.
            if key == "price_ton":
                return float(value)
            return float(value) / 1_000_000_000
    action = event.get("saleAction")
    if isinstance(action, dict):
        value = action.get("amountTon")
        if isinstance(value, (int, float)):
            return float(value) / 1_000_000_000
        value = action.get("amount")
        currency = str(action.get("currency", "")).lower()
        if isinstance(value, (int, float)) and currency in {"ton", "gram"}:
            return float(value) / 1_000_000_000
    return None

def normalize_history(payload):
    rows = []
    for event in unwrap_events(payload):
        if not isinstance(event, dict):
            continue
        kind = str(event.get("event") or event.get("type") or event.get("kind") or "").lower()
        at = parse_date(event.get("at") or event.get("date") or event.get("timestamp") or event.get("createdAt"))
        price = event_price_ton(event)
        rows.append({"kind": kind, "at": at, "price_ton": price, "raw": event})
    return rows
