import asyncio
import json
import logging
from urllib.parse import quote
import websockets
from aiogram import Bot
from .providers.see_tg import event_price_ton

log = logging.getLogger(__name__)
WS_URL = "wss://live.see.tg/v1/ws"

def field(event, *names):
    for name in names:
        if event.get(name) not in (None, ""):
            return str(event[name])
    return ""

def event_matches(event, user):
    gift = event.get("gift") if isinstance(event.get("gift"), dict) else {}
    price = event_price_ton(event)
    if price is None:
        return False
    if user.get("max_price_ton") is not None and price > float(user["max_price_ton"]):
        return False
    mapping = {
        "collection": ("slug", "collection", "title"),
        "model": ("model",),
        "backdrop": ("backdrop", "background"),
        "pattern": ("pattern", "symbol"),
    }
    for setting, keys in mapping.items():
        expected = (user.get(setting) or "").strip().casefold()
        if expected:
            actual = field(gift, *keys).casefold()
            if not actual or expected not in actual:
                return False
    return True

def gift_link(gift):
    slug = field(gift, "slug")
    num = field(gift, "num", "number")
    if slug and num:
        return f"https://t.me/nft/{slug}-{num}"
    gift_id = field(gift, "id")
    if slug:
        return f"https://t.me/nft/{slug}"
    return ""

async def run_radar(bot: Bot, db, token: str):
    if not token:
        log.warning("SEE_TG_TOKEN не задан: live Gift Radar отключён.")
        return
    url = f"{WS_URL}?token={quote(token, safe=':')}"
    while True:
        try:
            async with websockets.connect(url, ping_interval=None, close_timeout=5, max_size=2**20) as ws:
                await ws.send(json.dumps({"type": "subscribe", "events": ["all"]}))
                async for message in ws:
                    try:
                        packet = json.loads(message)
                    except json.JSONDecodeError:
                        continue
                    if not isinstance(packet, dict):
                        continue
                    # Documented feed envelope is commonly {"type":"event","event":"listing", ...}.
                    # Some deployments may wrap the payload under an event object.
                    event = packet.get("event") if isinstance(packet.get("event"), dict) else packet
                    kind_value = event.get("event") if isinstance(event.get("event"), str) else event.get("type")
                    kind = str(kind_value or "").lower()
                    if kind not in {"listing", "price"}:
                        continue
                    event_id = str(event.get("eventId") or event.get("id") or "")
                    if not event_id or not db.mark_event_seen(event_id):
                        continue
                    gift = event.get("gift") if isinstance(event.get("gift"), dict) else {}
                    price = event_price_ton(event)
                    if price is None:
                        continue
                    for user in db.enabled_users():
                        if event_matches(event, user):
                            link = gift_link(gift)
                            title = field(gift, "title", "slug") or "Telegram NFT Gift"
                            attrs = []
                            for label, key in (("Модель", "model"), ("Фон", "backdrop"), ("Узор", "pattern")):
                                if gift.get(key):
                                    attrs.append(f"{label}: {gift[key]}")
                            text = f"🎯 <b>Найден лот</b>\n{title}\nЦена: <b>{price:.3f} TON</b>"
                            if attrs:
                                text += "\n" + "\n".join(attrs)
                            if link:
                                text += f'\n<a href="{link}">Открыть подарок</a>'
                            text += "\n\nИсточник: see.tg. Проверяйте цену и лот перед покупкой."
                            try:
                                await bot.send_message(user["user_id"], text, disable_web_page_preview=True)
                            except Exception:
                                log.exception("Не удалось отправить радарное уведомление")
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("Gift Radar WebSocket оборвался; повтор через 5 секунд")
            await asyncio.sleep(5)
