from statistics import median, mean
from datetime import datetime, timezone
from .providers.see_tg import START_2026

SALE_WORDS = ("sale", "sold", "purchase", "soldout")

def value_history(rows):
    sales = []
    for row in rows:
        kind = row["kind"].lower()
        if not any(word in kind for word in SALE_WORDS):
            continue
        at = row["at"]
        price = row["price_ton"]
        if not at or at < START_2026 or price is None or price <= 0:
            continue
        sales.append((at, price))
    sales.sort(key=lambda x: x[0], reverse=True)
    prices = [p for _, p in sales]
    return {
        "count": len(prices),
        "median": median(prices) if prices else None,
        "average": mean(prices) if prices else None,
        "latest": sales[0][1] if sales else None,
        "latest_date": sales[0][0] if sales else None,
        "sales": sales,
    }

def format_ton(value):
    if value is None:
        return "нет данных"
    return f"{value:,.3f}".replace(",", " ") + " TON"
